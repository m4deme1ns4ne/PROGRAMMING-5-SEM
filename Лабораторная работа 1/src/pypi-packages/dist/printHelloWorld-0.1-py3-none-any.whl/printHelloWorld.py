def printHelloWorldfunc() -> str:
    print("Hello, World!")
